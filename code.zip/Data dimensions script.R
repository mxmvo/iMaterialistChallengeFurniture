

directory = base::dir("C:/Users/Oliver/Desktop/kaggle comp/")
images <- list()
source("https://bioconductor.org/biocLite.R")
biocLite("EBImage")
for(i in paste("C:/Users/Oliver/Desktop/kaggle comp/",directory,"/",sep="")){
  images[[i]] <- matrix(nrow=length(dir(i)),ncol=5)
  colnames(images[[i]]) <- c('ID','File Size','Pixels X','Pixels Y','RGB')
  direc <- dir(i)
  print(i)
  længde = length(direc)
  time <- system.time(
    for(j in 1:længde){
    #print(j)
    images[[i]][j,1] <- direc[j]
    images[[i]][j,2] <- base::file.size(paste(i,direc[j],sep=""))
    image <- EBImage::readImage(paste(i,direc[j],sep=""))
    images[[i]][j,3:5] <- attr(image,"dim")
    
    #progress bar! it is fucking awesome!
    cat((paste("\rProgress in directory '",i,"': [",paste(rep("#",floor((j*50)/længde)),collapse=""),paste(rep("-",floor((længde - j)*50/længde)),collapse=""),"].   ",j, " of ", længde,sep="",collapse=)))
    }
  )
  print(paste("Time spent: ", time,sep=""))
  Sys.sleep(3)
}

images[[1]][,1] <- substr(images[[1]][,1],1,nchar(images[[1]][,1])-4)
images[[2]][,1] <- substr(images[[2]][,1],1,nchar(images[[2]][,1])-4)
images[[3]][,1] <- substr(images[[3]][,1],1,nchar(images[[3]][,1])-4)

write.table(images[[1]],file="C:/Users/Oliver/Desktop/kaggle comp/test_summary.rdata",row.names = F)
write.table(images[[2]],file="C:/Users/Oliver/Desktop/kaggle comp/train_summary.rdata",row.names = F)
write.table(images[[3]],file="C:/Users/Oliver/Desktop/kaggle comp/validation_summary.rdata",row.names = F)
rm(list=ls())
?EBImage::resize
test <- read.table("C:/Users/Oliver/Desktop/kaggle comp/train_summary.rdata",header=T)
test[,1] <- as.factor(test[,1])
nrow(subset(test,Pixels.X == 1 & Pixels.Y == 1))
summary(test)



