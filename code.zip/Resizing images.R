
#Resizing of images using EBImage
#no flipping 
cl <- parallel::makeCluster(parallel::detectCores())
cl <- parallel::makeCluster(2)
direc <- dir("C:/Users/Oliver/Desktop/kaggle comp/validation/")
set.seed(123)
image.sample <- direc
resize.sample <- function(x){
  
  if(!(dir.exists("C:/Users/Oliver/Desktop/kaggle comp/validation/resized/"))){
    dir.create("C:/Users/Oliver/Desktop/kaggle comp/validation/resized/")
  }
  if(!(file.exists(paste("C:/Users/Oliver/Desktop/kaggle comp/validation/resized/",x,sep="")))){
    current.image <- EBImage::readImage(paste("C:/Users/Oliver/Desktop/kaggle comp/validation/",x,sep=""))
    current.image <- EBImage::resize(current.image,224,224)
    EBImage::writeImage(current.image,paste("C:/Users/Oliver/Desktop/kaggle comp/validation/resized/",x,sep=""))
  }
}
#C:\Users\Oliver\Desktop\kaggle comp\train\resized
parallel::clusterMap(cl,fun=resize.sample,x=image.sample)
parallel::stopCluster(cl)
