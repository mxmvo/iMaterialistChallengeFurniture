#Install required packages
install.packages(c("jsonlite","readr"))
options(encoding = "UTF8")
#Read the required libraries
library("jsonlite") #Reads json files
library("readr") #Causes less broken images to fuck up
library("parallel") #parallel processing
#Read the file
#'C:\Users\kueze\Dropbox\Oliver\Skole\Kandidat\LSDA\Competition\Furniture'
json_file <- 'C:/Users/kueze/Dropbox/Oliver/Skole/Kandidat/LSDA/Competition/Furniture/sample_submission.json'
json_data <- fromJSON(json_file)
#Split the lists into sub lists
images <- as.data.frame(json_data$images)
annotations <- as.data.frame(json_data$annotations)
#Remove the original file to save space and speed up the process
rm(json_data)
#Merge the data to the file data frame
data <- merge(images,annotations, by=c("image_id"))
#Remove the original file to save space and speed up the process
rm(list=c("images","annotations"))
#Create a download function. download.file interrupts run time if it cannot access an URL; to avoid this use try. 
#quite sets it to ignore all output. 
don <- function(url,destination){
  if(!(file.exists(destination))){
    try(download.file(url=url,destfile=destination,quiet=TRUE,mode="wb"))
  
  }else{
    print(paste("File existed at: ", destination,sep="  "))
  }
}

#Create a cluster for forking hte process
cl <- parallel::makeCluster(parallel::detectCores())

#run the process over all clusters.
clusterMap(cl, don, url = data[,2], dest =paste("C:/Users/kueze/Desktop/Images Kaggle Comp/image_",data[,1],".jpeg",sep=""), .scheduling = 'dynamic')
parallel::stopCluster(cl)
